export default function Home() {
  return <div className="p-6">Welcome. Redirecting to dashboard…</div>;
}
