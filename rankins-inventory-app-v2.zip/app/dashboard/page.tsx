export default function Dashboard() {
  return (
    <main className="p-6 space-y-4">
      <h1 className="text-2xl font-semibold">Inventory Dashboard</h1>
      <p className="opacity-80">Start adding features here.</p>
    </main>
  );
}
