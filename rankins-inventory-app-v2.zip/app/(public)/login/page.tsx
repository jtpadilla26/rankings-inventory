"use client";
import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

export default function Login() {
  const [email, setEmail] = useState("");
  const router = useRouter();
  const back = useSearchParams().get("redirectedFrom") ?? "/dashboard";

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    // TODO: supabase.auth.signInWithOtp({ email });
    router.push(back);
  }

  return (
    <main className="mx-auto max-w-sm p-6">
      <h1 className="mb-4 text-2xl font-semibold">Sign in</h1>
      <form onSubmit={onSubmit} className="space-y-3">
        <input
          className="w-full rounded-md border bg-background p-2"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="name@company.com"
        />
        <button className="w-full rounded-md bg-primary p-2 text-primary-foreground">
          Continue
        </button>
      </form>
    </main>
  );
}
