import { NextResponse } from "next/server";

export async function GET() {
  // TODO: fetch items from Supabase
  return NextResponse.json({ ok: true, items: [] });
}

export async function POST(req: Request) {
  const payload = await req.json().catch(() => null);
  // TODO: insert/update in Supabase
  return NextResponse.json({ ok: true, received: payload });
}
